;===========================================================
; PIC16F887 - LCD 16x2 - Santa Marta + hora incremental
; Oscilador: Cristal de 4 MHz
; LCD en modo 4 bits
;
; RB0 -> RS
; RB1 -> E
; RB4 -> D4
; RB5 -> D5
; RB6 -> D6
; RB7 -> D7
;===========================================================

        LIST    P=16F887
        #include <P16F887.INC>

;-----------------------------------------------------------
; CONFIGURACION
;-----------------------------------------------------------
        __CONFIG _CONFIG1, _FOSC_XT & _WDTE_OFF & _PWRTE_ON & _MCLRE_ON & _CP_OFF & _CPD_OFF & _BOREN_OFF & _IESO_OFF & _FCMEN_OFF & _LVP_OFF
        __CONFIG _CONFIG2, _BOR4V_BOR40V & _WRT_OFF

;-----------------------------------------------------------
; VARIABLES
;-----------------------------------------------------------
        CBLOCK  0x20
            HORA
            MINUTO
            TEMP
            TEMP2
            TEMP3
            CONT1
            CONT2
            CONT3
        ENDC

;-----------------------------------------------------------
; VECTOR DE RESET
;-----------------------------------------------------------
        ORG     0x0000
        GOTO    INICIO

        ORG     0x0004
        RETFIE

;===========================================================
; INICIO
;===========================================================
INICIO:

        BANKSEL ANSEL
        CLRF    ANSEL
        CLRF    ANSELH

        BANKSEL TRISB
        CLRF    TRISB

        BANKSEL PORTB
        CLRF    PORTB

        ; Hora inicial 07:01 AM
        MOVLW   .7
        MOVWF   HORA

        MOVLW   .1
        MOVWF   MINUTO

        ; Inicializar LCD
        CALL    LCD_INIT

        ; Mostrar pantalla inicial
        CALL    MOSTRAR_PANTALLA

BUCLE:

        ; Esperar aproximadamente 1 minuto
        CALL    RETARDO_1_MINUTO

        ; Incrementar minuto
        INCF    MINUTO,F

        MOVLW   .60
        SUBWF   MINUTO,W
        BTFSS   STATUS,Z
        GOTO    ACTUALIZAR

        ; Lleg� a 60 minutos
        CLRF    MINUTO

        ; Incrementar hora
        INCF    HORA,F

        ; Si llega a 13, volver a 1
        MOVLW   .13
        SUBWF   HORA,W
        BTFSS   STATUS,Z
        GOTO    ACTUALIZAR

        MOVLW   .1
        MOVWF   HORA

ACTUALIZAR:

        CALL    MOSTRAR_PANTALLA
        GOTO    BUCLE

;===========================================================
; MOSTRAR PANTALLA
;===========================================================
MOSTRAR_PANTALLA:

        ;-----------------------------------------------
        ; PRIMERA LINEA
        ; Santa Marta
        ;-----------------------------------------------

        MOVLW   0x80
        CALL    LCD_CMD

        MOVLW   'S'
        CALL    LCD_DATA

        MOVLW   'a'
        CALL    LCD_DATA

        MOVLW   'n'
        CALL    LCD_DATA

        MOVLW   't'
        CALL    LCD_DATA

        MOVLW   'a'
        CALL    LCD_DATA

        MOVLW   ' '
        CALL    LCD_DATA

        MOVLW   'M'
        CALL    LCD_DATA

        MOVLW   'a'
        CALL    LCD_DATA

        MOVLW   'r'
        CALL    LCD_DATA

        MOVLW   't'
        CALL    LCD_DATA

        MOVLW   'a'
        CALL    LCD_DATA

        ;-----------------------------------------------
        ; SEGUNDA LINEA
        ; Hora: 07:01 AM
        ;-----------------------------------------------

        MOVLW   0xC0
        CALL    LCD_CMD

        MOVLW   'H'
        CALL    LCD_DATA

        MOVLW   'o'
        CALL    LCD_DATA

        MOVLW   'r'
        CALL    LCD_DATA

        MOVLW   'a'
        CALL    LCD_DATA

        MOVLW   ':'
        CALL    LCD_DATA

        MOVLW   ' '
        CALL    LCD_DATA

        ; Mostrar hora
        MOVF    HORA,W
        CALL    MOSTRAR_2_DIGITOS

        MOVLW   ':'
        CALL    LCD_DATA

        ; Mostrar minutos
        MOVF    MINUTO,W
        CALL    MOSTRAR_2_DIGITOS

        MOVLW   ' '
        CALL    LCD_DATA

        MOVLW   'A'
        CALL    LCD_DATA

        MOVLW   'M'
        CALL    LCD_DATA

        RETURN

;===========================================================
; MOSTRAR DOS DIGITOS
; Entrada: W = numero de 0 a 99
;===========================================================
MOSTRAR_2_DIGITOS:

        MOVWF   TEMP

        CLRF    TEMP2

CALC_DECENAS:

        MOVLW   .10
        SUBWF   TEMP,F

        BTFSS   STATUS,C
        GOTO    FIN_DECENAS

        INCF    TEMP2,F
        GOTO    CALC_DECENAS

FIN_DECENAS:

        MOVF    TEMP,W
        ADDLW   '0'
        CALL    LCD_DATA

        MOVF    TEMP2,W
        ADDLW   '0'
        CALL    LCD_DATA

        RETURN

;===========================================================
; INICIALIZACION LCD
;===========================================================
LCD_INIT:

        CALL    RETARDO_20MS

        BANKSEL PORTB

        BCF     PORTB,0
        BCF     PORTB,1

        ; Inicializacion en 8 bits
        MOVLW   0x30
        CALL    LCD_NIBBLE_RAW

        CALL    RETARDO_5MS

        MOVLW   0x30
        CALL    LCD_NIBBLE_RAW

        CALL    RETARDO_1MS

        MOVLW   0x30
        CALL    LCD_NIBBLE_RAW

        CALL    RETARDO_1MS

        ; Cambiar a 4 bits
        MOVLW   0x20
        CALL    LCD_NIBBLE_RAW

        CALL    RETARDO_1MS

        ; 4 bits, 2 lineas, matriz 5x8
        MOVLW   0x28
        CALL    LCD_CMD

        ; Display encendido, cursor apagado
        MOVLW   0x0C
        CALL    LCD_CMD

        ; Incrementar cursor
        MOVLW   0x06
        CALL    LCD_CMD

        ; Limpiar pantalla
        MOVLW   0x01
        CALL    LCD_CMD

        CALL    RETARDO_2MS

        RETURN

;===========================================================
; ENVIAR COMANDO LCD
;===========================================================
LCD_CMD:

        BANKSEL PORTB

        BCF     PORTB,0

        MOVWF   TEMP3

        CALL    LCD_SEND_BYTE

        RETURN

;===========================================================
; ENVIAR DATO LCD
;===========================================================
LCD_DATA:

        BANKSEL PORTB

        BSF     PORTB,0

        MOVWF   TEMP3

        CALL    LCD_SEND_BYTE

        RETURN

;===========================================================
; ENVIAR BYTE COMPLETO
;===========================================================
LCD_SEND_BYTE:

        ; NIBBLE ALTO
        MOVF    TEMP3,W

        ANDLW   0xF0

        MOVWF   TEMP

        MOVF    PORTB,W

        ANDLW   0x03

        IORWF   TEMP,W

        MOVWF   PORTB

        CALL    LCD_PULSE_E

        ; NIBBLE BAJO
        SWAPF   TEMP3,W

        ANDLW   0xF0

        MOVWF   TEMP

        MOVF    PORTB,W

        ANDLW   0x03

        IORWF   TEMP,W

        MOVWF   PORTB

        CALL    LCD_PULSE_E

        CALL    RETARDO_CORTO

        RETURN

;===========================================================
; ENVIAR NIBBLE DURANTE INICIALIZACION
;===========================================================
LCD_NIBBLE_RAW:

        ANDLW   0xF0

        MOVWF   TEMP

        MOVF    PORTB,W

        ANDLW   0x03

        IORWF   TEMP,W

        MOVWF   PORTB

        CALL    LCD_PULSE_E

        RETURN

;===========================================================
; PULSO ENABLE
;===========================================================
LCD_PULSE_E:

        BSF     PORTB,1

        NOP
        NOP
        NOP

        BCF     PORTB,1

        RETURN

;===========================================================
; RETARDO CORTO
;===========================================================
RETARDO_CORTO:

        MOVLW   .20

        MOVWF   CONT1

RC1:

        NOP
        NOP

        DECFSZ  CONT1,F

        GOTO    RC1

        RETURN

;===========================================================
; RETARDO 1 MILISEGUNDO
;===========================================================
RETARDO_1MS:

        MOVLW   .250

        MOVWF   CONT1

R1MS:

        NOP
        NOP

        DECFSZ  CONT1,F

        GOTO    R1MS

        RETURN

;===========================================================
; RETARDO 2 MILISEGUNDOS
;===========================================================
RETARDO_2MS:

        CALL    RETARDO_1MS
        CALL    RETARDO_1MS

        RETURN

;===========================================================
; RETARDO 5 MILISEGUNDOS
;===========================================================
RETARDO_5MS:

        CALL    RETARDO_1MS
        CALL    RETARDO_1MS
        CALL    RETARDO_1MS
        CALL    RETARDO_1MS
        CALL    RETARDO_1MS

        RETURN

;===========================================================
; RETARDO 20 MILISEGUNDOS
;===========================================================
RETARDO_20MS:

        MOVLW   .20

        MOVWF   CONT2

R20:

        CALL    RETARDO_1MS

        DECFSZ  CONT2,F

        GOTO    R20

        RETURN

;===========================================================
; RETARDO 250 MILISEGUNDOS
;===========================================================
RETARDO_250MS:

        MOVLW   .250

        MOVWF   CONT3

R250:

        CALL    RETARDO_1MS

        DECFSZ  CONT3,F

        GOTO    R250

        RETURN

;===========================================================
; RETARDO 1 SEGUNDO
;===========================================================
RETARDO_1S:

        CALL    RETARDO_250MS
        CALL    RETARDO_250MS
        CALL    RETARDO_250MS
        CALL    RETARDO_250MS

        RETURN

;===========================================================
; RETARDO 1 MINUTO
;===========================================================
RETARDO_1_MINUTO:

        MOVLW   .60

        MOVWF   CONT3

RMIN:

        CALL    RETARDO_1S

        DECFSZ  CONT3,F

        GOTO    RMIN

        RETURN

        END